<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;
use App\Models\Category;

class BookController extends Controller
{
    public function index() {
        // logic tampil buku
    }

    public function create() {
        // tampil form tambah
    }

    public function store(Request $request) {
        // simpan buku
    }

    public function edit($id) {
        // form edit buku
    }

    public function update(Request $request, $id) {
        // update data buku
    }

    public function destroy($id) {
        // hapus buku
    }
}