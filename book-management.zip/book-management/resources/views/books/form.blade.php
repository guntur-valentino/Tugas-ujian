<!DOCTYPE html>
<html>
<head>
    <title>Form Buku</title>
</head>
<body>
    <h1>Tambah/Edit Buku</h1>
    <!-- Form input buku di sini -->
</body>
</html>