<!DOCTYPE html>
<html>
<head>
    <title>Manajemen Buku</title>
</head>
<body>
    <h1>Daftar Buku</h1>
    <!-- Tampilkan list buku dan fitur pencarian/filter di sini -->
</body>
</html>