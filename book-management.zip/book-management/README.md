# Book Management (Laravel 10)

Simple CRUD project for managing books.
